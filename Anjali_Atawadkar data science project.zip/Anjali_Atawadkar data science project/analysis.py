# ==============================
# IMPORTS
# ==============================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns # type: ignore

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

sns.set(style="whitegrid")

# ==============================
# LOAD DATA
# ==============================
trades = pd.read_csv("C:\\sers\\BC\\Python\\Anjali_Atawadkar data science project\\historical_data.csv")
sentiment = pd.read_csv("C:\\Users\\BC\\Python\\Anjali_Atawadkar data science project\\fear_greed_index.csv")

print("Trades shape:", trades.shape)
print("Sentiment shape:", sentiment.shape)

# ==============================
# CLEANING
# ==============================
trades = trades.drop_duplicates()
sentiment = sentiment.drop_duplicates()

trades["date"] = pd.to_datetime(trades["Timestamp IST"], dayfirst=True).dt.date
sentiment["date"] = pd.to_datetime(sentiment["date"]).dt.date

# ==============================
# MERGE
# ==============================
data = trades.merge(
    sentiment[["date","classification","value"]],
    on="date",
    how="left"
)

# ==============================
# FEATURE ENGINEERING
# ==============================
data["win"] = data["Closed PnL"] > 0

daily_pnl = data.groupby(["Account","date"])["Closed PnL"].sum().reset_index()

winrate = data.groupby("Account")["win"].mean().reset_index()
avg_size = data.groupby("Account")["Size USD"].mean().reset_index()

# ==============================
# ANALYSIS PLOTS
# ==============================
daily_perf = data.groupby(["date","classification"])["Closed PnL"].sum().reset_index()

plt.figure(figsize=(10,5))
sns.boxplot(x="classification", y="Closed PnL", data=daily_perf)
plt.title("PnL distribution — Fear vs Greed")
plt.savefig("outputs/pnl_vs_sentiment.png")
plt.close()

# Trade frequency
freq = data.groupby(["date","classification"]).size().reset_index(name="trades")

plt.figure(figsize=(8,5))
sns.barplot(x="classification", y="trades", data=freq)
plt.title("Trade frequency vs sentiment")
plt.savefig("outputs/trade_frequency.png")
plt.close()

# ==============================
# ADVANCED SEGMENTATION (CLUSTERING)
# ==============================
account_features = data.groupby("Account").agg({
    "Closed PnL":"mean",
    "Size USD":"mean",
    "Account":"count"
}).rename(columns={"Account":"trade_count"})

scaler = StandardScaler()
X_scaled = scaler.fit_transform(account_features)

kmeans = KMeans(n_clusters=3, random_state=42)
account_features["cluster"] = kmeans.fit_predict(X_scaled)

account_features.to_csv("outputs/trader_clusters.csv")

# ==============================
# BONUS — PREDICTIVE MODEL
# ==============================
features = data.groupby("date").agg({
    "Closed PnL":"sum",
    "Size USD":"mean",
    "classification":"first"
}).reset_index()

features["target"] = (features["Closed PnL"].shift(-1) > 0).astype(int)
features = pd.get_dummies(features, columns=["classification"], drop_first=True)
features = features.dropna()

X = features.drop(["date","target","Closed PnL"], axis=1)
y = features["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)

model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

pred = model.predict(X_test)
acc = accuracy_score(y_test, pred)

print("Model Accuracy:", acc)

print("Analysis completed ✅")