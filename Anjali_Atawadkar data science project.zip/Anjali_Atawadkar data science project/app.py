import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns # type: ignore

st.set_page_config(page_title="Trader Sentiment Dashboard")

st.title("Trader Behavior vs Market Sentiment")

trades = pd.read_csv("C:\\Users\\BC\\Python\\Anjali_Atawadkar data science project\\historical_data.csv")
sentiment = pd.read_csv("C:\\Users\\BC\\Python\\Anjali_Atawadkar data science project\\fear_greed_index.csv")

trades["date"] = pd.to_datetime(trades["Timestamp IST"], dayfirst=True).dt.date
sentiment["date"] = pd.to_datetime(sentiment["date"]).dt.date

data = trades.merge(sentiment, on="date", how="left")

st.subheader("PnL vs Sentiment")

daily_perf = data.groupby(["date","classification"])["Closed PnL"].sum().reset_index()

fig, ax = plt.subplots()
sns.boxplot(x="classification", y="Closed PnL", data=daily_perf, ax=ax)
st.pyplot(fig)

st.subheader("Trade Size Distribution")

fig2, ax2 = plt.subplots()
sns.boxplot(x="classification", y="Size USD", data=data, ax=ax2)
st.pyplot(fig2)

st.subheader("Trades per sentiment")

freq = data.groupby(["classification"]).size().reset_index(name="trades")
st.bar_chart(freq.set_index("classification"))